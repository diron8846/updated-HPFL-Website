import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { ArrowRight } from "lucide-react";
import youth from "@/assets/youth.jpg";
import community from "@/assets/community.jpg";
import bible from "@/assets/bible-pulpit.jpg";
import sermon from "@/assets/sermon.jpg";
import hero from "@/assets/hero-worship.jpg";
import give from "@/assets/give.jpg";

export const Route = createFileRoute("/ministries")({
  head: () => ({
    meta: [
      { title: "Ministries — Hope For Life Ministry" },
      { name: "description", content: "Find your place to belong, grow, and serve. Explore the ministries of Hope For Life Ministry." },
      { property: "og:title", content: "Ministries — Hope For Life Ministry" },
      { property: "og:description", content: "Find your place to belong, grow, and serve." },
    ],
  }),
  component: Ministries,
});

const ministries = [
  { img: youth, t: "Kids", tag: "Birth – 5th Grade", d: "A safe, joy-filled environment where children encounter Jesus through Bible stories, worship and play." },
  { img: hero, t: "Youth", tag: "6th – 12th Grade", d: "Wednesday nights and Sunday groups helping students build a faith that lasts." },
  { img: community, t: "Small Groups", tag: "All Ages", d: "Doing life together in homes around the city — studying scripture, praying, and sharing meals." },
  { img: bible, t: "Men's Ministry", tag: "Brotherhood", d: "Breakfast gatherings, retreats, and discipleship for men in every season of life." },
  { img: sermon, t: "Women's Ministry", tag: "Sisterhood", d: "Bible studies, mentoring, and friendship rooted in the gospel of grace." },
  { img: give, t: "Outreach", tag: "City & World", d: "Serving Springfield's vulnerable and partnering with missionaries around the world." },
];

function Ministries() {
  return (
    <>
      <PageHeader eyebrow="Belong · Grow · Serve" title="Find your place." subtitle="The Christian life was never meant to be lived alone. Step into a ministry that fits your season and join a community of faith." />

      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-10 grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {ministries.map((m) => (
            <article key={m.t} className="group">
              <div className="aspect-[4/5] overflow-hidden mb-5">
                <img src={m.img} alt={m.t} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <p className="eyebrow mb-3 text-[0.65rem]">{m.tag}</p>
              <h3 className="font-display text-3xl text-primary mb-3 group-hover:text-accent transition-colors">{m.t}</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">{m.d}</p>
              <Link to="/contact" className="text-sm font-semibold uppercase tracking-widest text-primary inline-flex items-center gap-2 hover:text-gold transition-colors">
                Get Involved <ArrowRight size={14} />
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-secondary py-20 text-center">
        <div className="mx-auto max-w-2xl px-6">
          <p className="eyebrow mb-6">Can't Find Your Fit?</p>
          <h2 className="font-display text-3xl md:text-5xl text-primary mb-6">Let's start a conversation.</h2>
          <Link to="/contact" className="btn-primary">Talk to a Pastor <ArrowRight size={16} /></Link>
        </div>
      </section>
    </>
  );
}
