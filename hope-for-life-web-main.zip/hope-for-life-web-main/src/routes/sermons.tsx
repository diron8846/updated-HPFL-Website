import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { PlayCircle, Download, Clock } from "lucide-react";
import sermon from "@/assets/sermon.jpg";
import bible from "@/assets/bible-pulpit.jpg";
import hero from "@/assets/hero-worship.jpg";

export const Route = createFileRoute("/sermons")({
  head: () => ({
    meta: [
      { title: "Sermons — Hope For Life Ministry" },
      { name: "description", content: "Watch and listen to the latest sermons from Pastor David Okonkwo and the teaching team at Hope For Life Ministry." },
      { property: "og:title", content: "Sermons — Hope For Life Ministry" },
      { property: "og:description", content: "Weekly Bible-rooted teaching from our pulpit." },
    ],
  }),
  component: Sermons,
});

const sermons = [
  { img: sermon, series: "Anchored", title: "The Hope That Holds the Soul", speaker: "Pastor David Okonkwo", date: "May 12, 2026", scripture: "Hebrews 6:13–20", duration: "42 min" },
  { img: hero, series: "Anchored", title: "When the Storm Doesn't Stop", speaker: "Pastor David Okonkwo", date: "May 5, 2026", scripture: "Mark 4:35–41", duration: "38 min" },
  { img: bible, series: "Anchored", title: "The God Who Cannot Lie", speaker: "Pastor Grace Bennett", date: "Apr 28, 2026", scripture: "Numbers 23:19", duration: "40 min" },
  { img: sermon, series: "Easter", title: "He Is Risen — And So Are We", speaker: "Pastor David Okonkwo", date: "Apr 21, 2026", scripture: "1 Corinthians 15", duration: "47 min" },
  { img: hero, series: "Lent", title: "The Long Road to Joy", speaker: "Pastor Grace Bennett", date: "Apr 14, 2026", scripture: "Luke 24:13–35", duration: "36 min" },
  { img: bible, series: "Lent", title: "Garden of Surrender", speaker: "Pastor David Okonkwo", date: "Apr 7, 2026", scripture: "Matthew 26:36–46", duration: "44 min" },
];

function Sermons() {
  const [featured, ...rest] = sermons;
  return (
    <>
      <PageHeader eyebrow="Teaching Library" title="Sermons from our pulpit." subtitle="Verse-by-verse teaching that meets the realities of everyday life with the timeless truth of God's Word." />

      {/* FEATURED */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <p className="eyebrow mb-6">Latest Message</p>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative group cursor-pointer">
              <div className="aspect-video overflow-hidden">
                <img src={featured.img} alt={featured.title} width={1400} height={1000} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="absolute inset-0 bg-primary/30 group-hover:bg-primary/10 transition-colors flex items-center justify-center">
                <PlayCircle size={80} strokeWidth={1} className="text-gold drop-shadow-2xl" />
              </div>
            </div>
            <div>
              <div className="eyebrow mb-4">{featured.series} · Series</div>
              <h2 className="font-display text-4xl md:text-5xl text-primary leading-tight mb-5">{featured.title}</h2>
              <p className="text-muted-foreground mb-6">{featured.speaker} · {featured.date}</p>
              <div className="flex gap-6 text-sm text-muted-foreground mb-8 border-y border-border py-4">
                <span><strong className="text-primary">Scripture:</strong> {featured.scripture}</span>
                <span className="inline-flex items-center gap-1.5"><Clock size={14} /> {featured.duration}</span>
              </div>
              <div className="flex flex-wrap gap-3">
                <button className="btn-primary"><PlayCircle size={16} /> Watch</button>
                <button className="btn-gold"><Download size={16} /> Download</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* LIBRARY */}
      <section className="bg-secondary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="flex items-end justify-between mb-12">
            <h2 className="font-display text-3xl md:text-5xl text-primary">Recent Messages</h2>
            <div className="hidden md:flex gap-2 text-xs uppercase tracking-widest">
              {["All", "Anchored", "Easter", "Lent"].map((t, i) => (
                <button key={t} className={`px-4 py-2 border ${i === 0 ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary hover:text-primary"} transition-colors`}>{t}</button>
              ))}
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {rest.map((s) => (
              <article key={s.title} className="group bg-background">
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img src={s.img} alt={s.title} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-primary/20 group-hover:bg-primary/0 transition-colors flex items-center justify-center">
                    <PlayCircle size={48} strokeWidth={1} className="text-gold opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <div className="p-6">
                  <p className="eyebrow mb-3 text-[0.65rem]">{s.series}</p>
                  <h3 className="font-display text-2xl text-primary mb-3 leading-snug group-hover:text-accent transition-colors">{s.title}</h3>
                  <p className="text-sm text-muted-foreground mb-1">{s.speaker}</p>
                  <p className="text-xs text-muted-foreground/80">{s.date} · {s.scripture} · {s.duration}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
