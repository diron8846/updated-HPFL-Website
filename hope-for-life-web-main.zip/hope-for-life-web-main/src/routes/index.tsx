import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Calendar, Heart, PlayCircle, Users } from "lucide-react";
import hero from "@/assets/hero-worship.jpg";
import bible from "@/assets/bible-pulpit.jpg";
import community from "@/assets/community.jpg";
import sermon from "@/assets/sermon.jpg";
import youth from "@/assets/youth.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hope For Life Ministry — Welcome Home" },
      { name: "description", content: "A Christ-centered church in Springfield. Sunday worship at 9 & 11 AM. Find belonging, hope and purpose at Hope For Life Ministry." },
      { property: "og:title", content: "Hope For Life Ministry" },
      { property: "og:description", content: "A Christ-centered community of faith, hope and love." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      {/* HERO */}
      <section className="relative isolate min-h-[92vh] flex items-end">
        <img src={hero} alt="Congregation worshipping" width={1600} height={1200} className="absolute inset-0 h-full w-full object-cover -z-10" />
        <div className="absolute inset-0 -z-10" style={{ background: "var(--gradient-hero)" }} />
        <div className="mx-auto max-w-7xl w-full px-6 lg:px-10 py-20 lg:py-28 text-primary-foreground">
          <p className="eyebrow mb-8">Hope For Life Ministry · Est. 1998</p>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-8xl leading-[0.92] max-w-4xl">
            Where hope <em className="text-gold not-italic font-normal">finds</em> a home.
          </h1>
          <p className="mt-8 max-w-xl text-lg text-primary-foreground/85 leading-relaxed">
            A Christ-centered community in Springfield proclaiming the Gospel of grace through worship, discipleship, and service.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link to="/about" className="btn-gold">Plan Your Visit <ArrowRight size={16} /></Link>
            <Link to="/sermons" className="btn-outline"><PlayCircle size={16} /> Watch Online</Link>
          </div>
        </div>
      </section>

      {/* VERSE BAND */}
      <section className="bg-secondary py-20 lg:py-28 text-center">
        <div className="mx-auto max-w-3xl px-6">
          <p className="eyebrow mb-6">Our Foundation</p>
          <p className="font-display text-3xl md:text-5xl leading-tight text-primary italic">
            "For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future."
          </p>
          <div className="rule-gold w-16 mx-auto mt-8" />
          <p className="mt-4 text-sm tracking-[0.25em] uppercase text-muted-foreground">Jeremiah 29:11</p>
        </div>
      </section>

      {/* MAGAZINE FEATURE GRID */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
            <div>
              <p className="eyebrow mb-5">This Week</p>
              <h2 className="font-display text-4xl md:text-6xl text-primary max-w-2xl leading-[1.05]">Stories shaping our community.</h2>
            </div>
            <Link to="/events" className="text-sm font-semibold uppercase tracking-widest text-primary hover:text-gold transition-colors inline-flex items-center gap-2">
              All Stories <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid lg:grid-cols-12 gap-10">
            {/* Featured */}
            <article className="lg:col-span-7 group">
              <Link to="/sermons" className="block">
                <div className="aspect-[4/3] overflow-hidden mb-6">
                  <img src={sermon} alt="Sunday sermon" width={1400} height={1000} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <p className="eyebrow mb-3">Featured Sermon Series</p>
                <h3 className="font-display text-3xl md:text-4xl text-primary leading-tight group-hover:text-accent transition-colors">
                  Anchored: Finding Steady Ground in Shifting Seasons
                </h3>
                <p className="mt-4 text-muted-foreground leading-relaxed max-w-xl">
                  Pastor David Okonkwo opens Hebrews 6 with a fresh look at the hope that holds the soul.
                </p>
              </Link>
            </article>

            {/* Side stories */}
            <div className="lg:col-span-5 flex flex-col gap-10">
              {[
                { img: community, eyebrow: "Community", title: "Welcome Night — Meet the Pastors", to: "/about" },
                { img: youth, eyebrow: "Next Generation", title: "Kids & Youth Programs Restart Sept 8", to: "/ministries" },
                { img: bible, eyebrow: "Discipleship", title: "Fall Bible Study: The Book of John", to: "/events" },
              ].map((s) => (
                <Link to={s.to} key={s.title} className="group grid grid-cols-[140px_1fr] gap-5 items-center">
                  <div className="aspect-square overflow-hidden">
                    <img src={s.img} alt="" loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div>
                    <p className="eyebrow mb-2 text-[0.65rem]">{s.eyebrow}</p>
                    <h4 className="font-display text-xl text-primary leading-snug group-hover:text-accent transition-colors">{s.title}</h4>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* WHAT TO EXPECT — split */}
      <section className="bg-primary text-primary-foreground py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10 grid lg:grid-cols-2 gap-16 items-center">
          <div className="aspect-[4/5] overflow-hidden">
            <img src={community} alt="Our community" loading="lazy" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow mb-6">First Time Here?</p>
            <h2 className="font-display text-4xl md:text-6xl leading-[1.05] mb-8">You're already family — you just haven't met us yet.</h2>
            <p className="text-primary-foreground/80 text-lg leading-relaxed mb-10">
              Walk in as you are. Coffee is hot, the welcome is warm, and our team will help you find your way. Services last about 75 minutes with worship, scripture, and a Bible-rooted message.
            </p>
            <div className="space-y-6 mb-10">
              {[
                { t: "Sunday Worship", d: "9:00 AM & 11:00 AM" },
                { t: "Kids & Youth", d: "Programs for every age, both services" },
                { t: "Address", d: "123 Grace Avenue, Springfield, IL" },
              ].map((i) => (
                <div key={i.t} className="border-b border-primary-foreground/15 pb-5">
                  <p className="font-display text-2xl text-gold">{i.t}</p>
                  <p className="text-primary-foreground/75 mt-1">{i.d}</p>
                </div>
              ))}
            </div>
            <Link to="/contact" className="btn-gold">Plan a Visit <ArrowRight size={16} /></Link>
          </div>
        </div>
      </section>

      {/* PILLARS */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">How We Live</p>
            <h2 className="font-display text-4xl md:text-6xl text-primary">Three pillars of life together.</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { Icon: Heart, t: "Worship", d: "Gathering weekly to lift Christ high through scripture, song and sacrament." },
              { Icon: Users, t: "Community", d: "Doing life in small groups where faith is shared and burdens are carried together." },
              { Icon: Calendar, t: "Mission", d: "Serving our city and the nations with the love and message of Jesus." },
            ].map(({ Icon, t, d }) => (
              <div key={t} className="border-t-2 border-gold pt-8">
                <Icon className="text-accent mb-6" size={32} strokeWidth={1.5} />
                <h3 className="font-display text-3xl text-primary mb-3">{t}</h3>
                <p className="text-muted-foreground leading-relaxed">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GIVE CTA */}
      <section className="bg-secondary py-24 lg:py-32">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <p className="eyebrow mb-6">Partner With Us</p>
          <h2 className="font-display text-4xl md:text-6xl text-primary leading-[1.05] mb-6">Every gift moves the mission forward.</h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-10 max-w-2xl mx-auto">
            Your generosity fuels worship, discipleship, outreach, and care for those in need — here in Springfield and around the world.
          </p>
          <Link to="/give" className="btn-primary">Give Now <ArrowRight size={16} /></Link>
        </div>
      </section>
    </>
  );
}
